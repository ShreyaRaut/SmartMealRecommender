//Name -Shreya Raut, Andrew id -sraut2
package ds.edu.cmu;

import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.SeekBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import ds.edu.cmu.databinding.FragmentFirstBinding;

public class FirstFragment extends Fragment {

    private FragmentFirstBinding binding;
    private String selectedMealType = "breakfast"; // Default selection
    private int selectedTime = 30; // Default time in minutes

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentFirstBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Handle Spinner Selection
        binding.spinnerMealType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedMealType = parent.getItemAtPosition(position).toString().toLowerCase();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                selectedMealType = "breakfast"; // Fallback default
            }
        });

        // Handle SeekBar Changes
        binding.seekBarTime.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                selectedTime = progress;
                binding.textViewTime.setText("Time Available: " + progress + " mins");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // Not needed
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // Not needed
            }
        });

        // Handle Button Click to fetch recipes using a background task
        binding.buttonFetchRecipes.setOnClickListener(v -> {
            String ingredients = binding.editTextIngredients.getText().toString().toLowerCase().trim();

            if (ingredients.isEmpty()) {
                Toast.makeText(getContext(), "Please enter at least one ingredient!", Toast.LENGTH_SHORT).show();
                return;
            }
            Toast.makeText(getContext(), "Starting network request...", Toast.LENGTH_SHORT).show();

            // Execute the background task to perform the HTTP request
            new GetRecipesTask().execute(ingredients, selectedTime, selectedMealType);
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    // Inner class to perform HTTP request in background
    private class GetRecipesTask {
        // Execute the background task with given parameters
        public void execute(String ingredients, int time, String mealType) {
            new Thread(() -> {
                // Perform the HTTP request off the UI thread
                String jsonResponse = doInBackground(ingredients, time, mealType);
                System.out.println(jsonResponse);
                // Once done, update the UI on the main thread
                requireActivity().runOnUiThread(() -> onPostExecute(jsonResponse));
            }).start();
        }

        // Performs the HTTP GET request and returns the JSON response as a String
        private String doInBackground(String ingredients, int time, String mealType) {
            try {
                // Replace with your server's IP, port, and context path
                String baseUrl = "https://orange-space-spork-6rw7vr5g6vqcrj76-8080.app.github.dev/getRecipes?";
                String encodedIngredients = URLEncoder.encode(ingredients, "UTF-8");
                String encodedMealType = URLEncoder.encode(mealType, "UTF-8");
                //ingredients=egg&meal_type=breakfast&time=30

                String[] ingredients_arr = encodedIngredients.split(",");

                String ingredients_url="";
                for (int i = 0; i < ingredients_arr.length; i++) {
                    ingredients_url += ingredients_arr[i]+"%2C";
                }



                String fullUrl = baseUrl + "ingredients=" + ingredients_url +
                        "&meal_type=" + encodedMealType + "&time=" + time;

                Log.d("TAG",fullUrl);
                requireActivity().runOnUiThread(() ->
                        Toast.makeText(getContext(), "URL built: " + fullUrl, Toast.LENGTH_SHORT).show());

                URL url = new URL(fullUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");

                conn.setRequestProperty("Accept", "application/json");  // Set the Accept header
                //String userAgent = "AndroidApp/1.0 (Android " + Build.VERSION.RELEASE + "; " + Build.MODEL + ")";
                String userAgent = "AndroidApp/1.0 (Android "
                        + Build.VERSION.RELEASE + "; "
                        + Build.BRAND + " "
                        + Build.MODEL + "; "
                        + Build.DEVICE + "; "
                        + Build.ID + ")";
                System.out.println(userAgent);

                conn.setRequestProperty("User-Agent", userAgent);


                int responseCode = conn.getResponseCode();
                System.out.println("HTTP response code: " + responseCode);

                BufferedReader in;
                if (responseCode >= 200 && responseCode < 300) {
                    in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                } else {
                    in = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
                }

                StringBuilder responseBuilder = new StringBuilder();
                String line;
                while ((line = in.readLine()) != null) {
                    System.out.println("Line: " + line);  // log every line
                    responseBuilder.append(line);
                }
                in.close();

                Log.d("DEBUG_RESPONSE", responseBuilder.toString());
                return responseBuilder.toString();



            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        // Runs on the UI thread after background processing is complete
        private void onPostExecute(String jsonResponse) {
            if (jsonResponse != null) {
                // Pass the response data to SecondFragment via Bundle
                Bundle bundle = new Bundle();
                Log.d("TAG",jsonResponse);
                bundle.putString("recipes", jsonResponse);  // Update the key to match the one in SecondFragment
                NavHostFragment.findNavController(FirstFragment.this)
                        .navigate(R.id.action_FirstFragment_to_SecondFragment, bundle);
            } else {
                Toast.makeText(getContext(), "Failed to fetch recipes", Toast.LENGTH_SHORT).show();
            }
        }

    }
}
