//Name -Shreya Raut, Andrew id -sraut2
package ds.edu.cmu;

import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.text.style.URLSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import ds.edu.cmu.databinding.FragmentSecondBinding;

public class SecondFragment extends Fragment {

    private FragmentSecondBinding binding;

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        binding = FragmentSecondBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Handle Home Button Click (Navigate to FirstFragment)
        if (binding != null) {
            binding.buttonHome.setOnClickListener(v ->
                    NavHostFragment.findNavController(SecondFragment.this)
                            .navigate(R.id.action_SecondFragment_to_FirstFragment)
            );
        }



        // Retrieve the raw response string from the bundle
        String rawResponse = getArguments() != null ? getArguments().getString("recipes") : "";

        LinearLayout linearLayoutRecipes = view.findViewById(R.id.linearLayoutRecipes);

        if (rawResponse.isEmpty()) {
            Toast.makeText(getContext(), "No recipes to display", Toast.LENGTH_SHORT).show();
            return;
        }

        try {

            LayoutInflater inflater = getLayoutInflater();
            //Parse JSON array
            JSONArray recipesArray = new JSONArray(rawResponse);


            List<JSONObject> recipeList = new ArrayList<>();
            for (int i = 0; i < recipesArray.length(); i++) {
                recipeList.add(recipesArray.getJSONObject(i));
            }

            Collections.sort(recipeList, (a, b) -> {
                int proteinA = a.optInt("protein", 0);
                int proteinB = b.optInt("protein", 0);
                return Integer.compare(proteinB, proteinA); // descending
            });


            // We'll only display the top 10
            int count = Math.min(recipesArray.length(), 10);

            for (int i = 0; i < count; i++) {
                JSONObject recipeObj = recipesArray.getJSONObject(i);

                String name = recipeObj.optString("name", "N/A");

                int prepTime = recipeObj.optInt("prep_time_minutes", 0);
                int cookTime = recipeObj.optInt("cook_time_minutes", 0);
                int calories = recipeObj.optInt("calories", 0);
                int protein = recipeObj.optInt("protein", 0);
                int fat = recipeObj.optInt("fat", 0);
                int carbs = recipeObj.optInt("carbs", 0);
                String instructions = recipeObj.optString("instructions", "");
                String cuisine = recipeObj.optString("cuisine","");
                String video_url = recipeObj.optString("video_url", "");

                // Inflate card layout
                View cardView = inflater.inflate(R.layout.item_recipe_card, linearLayoutRecipes, false);

                // Bind data
                TextView tvTitle = cardView.findViewById(R.id.tvRecipeTitle);
                TextView tvNutrition = cardView.findViewById(R.id.tvNutritionInfo);
                TextView tvTime = cardView.findViewById(R.id.tvTimeInfo);
                TextView tvCuisine = cardView.findViewById(R.id.tvCuisine);
                TextView tvInstructions = cardView.findViewById(R.id.tvInstructions);
                TextView tvVideo = cardView.findViewById(R.id.tvVideo);

                tvTitle.setText(name);
                tvNutrition.setText(calories + " cal | 🍣 " + protein + "g | 🥖 " + carbs + "g | 🍔 " + fat + "g");
                tvTime.setText("Prep: " + prepTime + " min | Cook: " + cookTime + " min");
                tvCuisine.setText("Cuisine: " + cuisine);
                tvInstructions.setText("Instructions: " + instructions);

                SpannableString spannable = new SpannableString("Watch Video");
                spannable.setSpan(new URLSpan(video_url), 0, spannable.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                tvVideo.setText(spannable);
                tvVideo.setMovementMethod(LinkMovementMethod.getInstance());

                // Add to parent
                linearLayoutRecipes.addView(cardView);
            }
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(getContext(), "Error parsing recipes", Toast.LENGTH_SHORT).show();
        }


    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null; // Prevent memory leaks
    }
}
