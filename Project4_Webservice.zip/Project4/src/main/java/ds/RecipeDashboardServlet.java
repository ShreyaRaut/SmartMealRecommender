//Name -Shreya Raut, Andrew id -sraut2
package ds;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;
import com.google.gson.Gson;
import com.mongodb.client.model.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.mongodb.client.*;
import org.bson.Document;
import org.bson.conversions.Bson;

import static com.mongodb.client.model.Sorts.descending;

@WebServlet("/dashboard")
public class RecipeDashboardServlet extends HttpServlet {

    private MongoCollection<Document> collection, recipeCollection;

    @Override
    public void init() throws ServletException {
        String uri = "mongodb+srv://sraut2:4r5vwtXA49gwj2FX@project4.g1cdt.mongodb.net/?retryWrites=true&w=majority&appName=Project4";
        MongoClient mongoClient = MongoClients.create(uri);
        MongoDatabase database = mongoClient.getDatabase("dsproject1");
        collection = database.getCollection("app_logs");
        recipeCollection = database.getCollection("recipes");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        long totalRecipes = recipeCollection.countDocuments();
        long totalRequests = collection.countDocuments();
        double avgResponseTime = getAverageResponseTime();
        String avgRounded = String.format("%.2f", avgResponseTime);

        request.setAttribute("totalRecipes", totalRecipes);
        request.setAttribute("totalRequests", totalRequests);
        request.setAttribute("avgResponseTime", avgRounded);


        List<Document> appLogs = new ArrayList<>();
        FindIterable<Document> logs = collection.find().limit(50); // Limit for dashboard

        for (Document log : logs) {
            appLogs.add(log);
        }

        request.setAttribute("appLogs", appLogs);

        // 1. Cuisine breakdown
        Map<String, Integer> cuisineCountMap = new HashMap<>();
        FindIterable<Document> allRecipes = recipeCollection.find();

        for (Document doc : allRecipes) {
            String cuisineStr = doc.getString("cuisine");
            if (cuisineStr != null) {
                for (String c : cuisineStr.split(",")) {
                    String trimmed = c.trim();
                    cuisineCountMap.put(trimmed, cuisineCountMap.getOrDefault(trimmed, 0) + 1);
                }
            }
        }

        // Convert cuisine counts to sorted lists
        List<String> cuisineLabels = new ArrayList<>(cuisineCountMap.keySet());
        List<Integer> cuisineCounts = cuisineLabels.stream()
                .map(cuisineCountMap::get)
                .collect(Collectors.toList());

        // 2. Top 10 recipes by protein
        List<Document> topProteinDocs = recipeCollection.find()
                .sort(descending("nutrition.protein"))
                .limit(20)
                .into(new ArrayList<>());

        List<Map<String, Object>> topProteinRecipes = new ArrayList<>();
        List<String> proteinLabels = new ArrayList<>();
        List<Integer> proteinAmounts = new ArrayList<>();

        for (Document doc : topProteinDocs) {
            Map<String, Object> map = new HashMap<>();
            String name = doc.getString("name");
            map.put("name", name != null ? name : "Unknown");

            Document nutrition = doc.get("nutrition", Document.class);
            int protein = 0, carbs = 0, fats = 0, calories = 0;
            if (nutrition != null) {
                protein = nutrition.getInteger("protein", 0);
                carbs = nutrition.getInteger("carbs", 0);
                fats = nutrition.getInteger("fat", 0);
                calories = nutrition.getInteger("calories", 0);
            }

            map.put("nutrition", Map.of(
                    "protein", protein,
                    "carbs", carbs,
                    "fats", fats,
                    "calories", calories
            ));
            topProteinRecipes.add(map);

            proteinLabels.add(name != null ? name : "Unknown");
            proteinAmounts.add(protein);
        }


        List<Integer> hourLabels = new ArrayList<>();
        List<Integer> hourCounts = new ArrayList<>();

        List<Bson> pipelineByHour = List.of(
                Aggregates.project(Projections.fields(
                        Projections.computed("hour", new Document("$toInt", new Document("$substr", List.of("$time_of_day", 0, 2))))
                )),
                Aggregates.group("$hour", Accumulators.sum("count", 1)),
                Aggregates.sort(Sorts.ascending("_id"))
        );

        AggregateIterable<Document> resultsByHour = collection.aggregate(pipelineByHour);

        for (Document doc : resultsByHour) {
            Integer hour = doc.getInteger("_id");
            Integer count = doc.getInteger("count");
            hourLabels.add(hour);
            hourCounts.add(count);
        }

        List<String> osVersionLabels = new ArrayList<>();
        List<Integer> osVersionCounts = new ArrayList<>();

        List<Bson> pipelineByVersion = List.of(
                Aggregates.match(Filters.regex("osVersion", "Android")), // Only Android app requests
                Aggregates.group("$osVersion", Accumulators.sum("count", 1)),
                Aggregates.sort(Sorts.ascending("_id"))
        );

        AggregateIterable<Document> resultsByVersion = collection.aggregate(pipelineByVersion);

        for (Document doc : resultsByVersion) {
            String version = doc.getString("_id");
            Integer count = doc.getInteger("count");

            osVersionLabels.add(version);
            osVersionCounts.add(count);
        }


        // Send data to JSP
        Gson gson = new Gson();
        request.setAttribute("hourLabelsJson", gson.toJson(hourLabels));
        request.setAttribute("hourCountsJson", gson.toJson(hourCounts));

        request.setAttribute("versionLabelsJson", gson.toJson(osVersionLabels));
        request.setAttribute("versionCountsJson", gson.toJson(osVersionCounts));

        request.setAttribute("cuisineCountMap", gson.toJson(cuisineCountMap));
        request.setAttribute("cuisineLabelsJson", gson.toJson(cuisineLabels));
        request.setAttribute("cuisineCountsJson", gson.toJson(cuisineCounts));
        request.setAttribute("proteinLabelsJson", gson.toJson(proteinLabels));
        request.setAttribute("proteinDataJson", gson.toJson(proteinAmounts));
        request.setAttribute("topProteinRecipes", topProteinRecipes);

        request.getRequestDispatcher("/dashboard.jsp").forward(request, response);
    }
    private double getAverageResponseTime() {
        List<Document> logs = collection.find().into(new ArrayList<>());
        long totalTime = 0;
        for (Document log : logs) {
            totalTime += log.getLong("response_time_ms");
        }
        return logs.size() > 0 ? totalTime / (double) logs.size() : 0;
    }
}
