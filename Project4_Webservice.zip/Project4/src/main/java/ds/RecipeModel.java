//Name-Shreya Raut, Andrew ID-sraut2
package ds;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import java.util.ArrayList;
import java.util.List;
import com.google.gson.*;


public class RecipeModel {
    private int id;
    private String name;
    private Integer prepTime;
    private Integer cookTime;
    private int calories;
    private int fat;
    private int protein;
    private int carbs;
    private String cuisine;
    private String instructions;
    private String videoUrl;

    // Constructors
    public RecipeModel() {}

    public RecipeModel(int id, String name, Integer prepTime, Integer cookTime,
                       int calories, int fat, int protein, int carbs,
                       String cuisine, String instructions, String videoUrl) {
        this.id = id;
        this.name = name;
        this.prepTime = prepTime;
        this.cookTime = cookTime;
        this.calories = calories;
        this.fat = fat;
        this.protein = protein;
        this.carbs = carbs;
        this.cuisine = cuisine;
        this.instructions = instructions;
        this.videoUrl = videoUrl;
    }

    // Getters and Setters
    public int getId() { return id; }
    public String getName() { return name; }
    public Integer getPrepTime() { return prepTime; }
    public Integer getCookTime() { return cookTime; }
    public int getCalories() { return calories; }
    public int getFat() { return fat; }
    public int getProtein() { return protein; }
    public int getCarbs() { return carbs; }
    public String getCuisine() { return cuisine; }
    public String getInstructions() { return instructions; }
    public String getVideoUrl() { return videoUrl; }

    public static List<RecipeModel> parseFromJson(JsonArray recipes) {
        List<RecipeModel> recipeList = new ArrayList<>();

        for (JsonElement element : recipes) {
            JsonObject recipe = element.getAsJsonObject();
            RecipeModel model = new RecipeModel();

            model.id = recipe.get("id").getAsInt();
            model.name = recipe.get("name").getAsString();

            if (recipe.has("prep_time_minutes") && !recipe.get("prep_time_minutes").isJsonNull())
                model.prepTime = recipe.get("prep_time_minutes").getAsInt();

            if (recipe.has("cook_time_minutes") && !recipe.get("cook_time_minutes").isJsonNull())
                model.cookTime = recipe.get("cook_time_minutes").getAsInt();

            JsonObject nutrition = recipe.getAsJsonObject("nutrition");
            model.calories = nutrition.has("calories") ? nutrition.get("calories").getAsInt() : 0;
            model.fat = nutrition.has("fat") ? nutrition.get("fat").getAsInt() : 0;
            model.protein = nutrition.has("protein") ? nutrition.get("protein").getAsInt() : 0;
            model.carbs = nutrition.has("carbohydrates") ? nutrition.get("carbohydrates").getAsInt() : 0;

            // Cuisine tags
            JsonArray tagsArray = recipe.has("tags") ? recipe.getAsJsonArray("tags") : new JsonArray();
            StringBuilder cuisineBuilder = new StringBuilder();
            for (JsonElement tagElement : tagsArray) {
                JsonObject tag = tagElement.getAsJsonObject();
                if ("cuisine".equals(tag.get("root_tag_type").getAsString())) {
                    cuisineBuilder.append(tag.get("display_name").getAsString()).append(", ");
                }
            }
            if (cuisineBuilder.length() > 0) {
                cuisineBuilder.setLength(cuisineBuilder.length() - 2);
                model.cuisine = cuisineBuilder.toString();
            }

            // Instructions
            StringBuilder instructionsBuilder = new StringBuilder();
            JsonArray instructionsArray = recipe.getAsJsonArray("instructions");
            for (JsonElement step : instructionsArray) {
                JsonObject stepObj = step.getAsJsonObject();
                if (stepObj.has("display_text")) {
                    instructionsBuilder.append("- ").append(stepObj.get("display_text").getAsString()).append("\n");
                }
            }
            model.instructions = instructionsBuilder.toString();

            if (recipe.has("original_video_url") && !recipe.get("original_video_url").isJsonNull()) {
                model.videoUrl = recipe.get("original_video_url").getAsString();
            }

            recipeList.add(model);
        }

        return recipeList;
    }

}
