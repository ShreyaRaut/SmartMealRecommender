//Name -Shreya Raut, Andrew id -sraut2
package ds;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.LocalTime;
import java.util.List;
import com.mongodb.client.model.IndexOptions;
import com.mongodb.client.model.Indexes;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.google.gson.*;
import jakarta.servlet.http.HttpSession;
import com.mongodb.client.*;
import org.bson.Document;


@WebServlet("/getRecipes")
public class RecipeServlet extends HttpServlet {
    private static final String API_KEY = "f1e8c488acmsh19a0ebe3962799cp16726bjsn3a9dd15b5807";
    private static final String API_HOST = "tasty.p.rapidapi.com";
    private static final String BASE_URL = "https://tasty.p.rapidapi.com/recipes/list";
    private MongoCollection<Document> collection,recipeCollection;


    @Override
    public void init() throws ServletException {

        String uri = "mongodb+srv://sraut2:4r5vwtXA49gwj2FX@project4.g1cdt.mongodb.net/?retryWrites=true&w=majority&appName=Project4";

        MongoClient mongoClient = MongoClients.create(uri);
        MongoDatabase database = mongoClient.getDatabase("dsproject1");
        collection = database.getCollection("app_logs");
        recipeCollection = database.getCollection("recipes");
        recipeCollection.createIndex(Indexes.ascending("id"), new IndexOptions().unique(true));

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String meal_type = request.getParameter("meal_type");
        String ingredientsParam = request.getParameter("ingredients");
        String timeStr  = request.getParameter("time");
        int timeInt = Integer.parseInt(timeStr);

        if (timeInt <= 30) {
            timeStr = "under_30_minutes";
        } else if (timeInt <= 60) {
            timeStr = "under_60_minutes";
        } else {
            timeStr = "under_120_minutes";
        }


        String[] ingredients = ingredientsParam.split(",");

        String ingredients_url="";
        for (int i = 0; i < ingredients.length; i++) {
            ingredients_url += ingredients[i]+"%2C";
        }


        String url = "https://tasty.p.rapidapi.com/recipes/list?from=0&size=50&tags="+meal_type+
                "%2C&q="+timeStr+"%2C"+ingredients_url;



        System.out.println("Your recipe is " + url);

        // for logging
        String userAgent = request.getHeader("User-Agent");
        long start = System.currentTimeMillis();


        try {
            HttpRequest apiRequest = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("x-rapidapi-key", API_KEY)
                    .header("x-rapidapi-host", API_HOST)
                    .GET()
                    .build();

            HttpClient client = HttpClient.newHttpClient();
            HttpResponse<String> apiResponse = client.send(apiRequest, HttpResponse.BodyHandlers.ofString());

            // Parse JSON response
            JsonElement jsonElement = JsonParser.parseString(apiResponse.body());
            JsonObject jsonObject = jsonElement.getAsJsonObject();
            JsonArray recipes = jsonObject.getAsJsonArray("results");
            System.out.println("No of recipes " +recipes.size());

            List<RecipeModel> filteredRecipes = RecipeModel.parseFromJson(recipes);
            long end = System.currentTimeMillis();
            long responseTime = end - start;


            String json_response = new GsonBuilder().setPrettyPrinting().create().toJson(filteredRecipes);

            HttpSession session = request.getSession();

            if (userAgent != null && userAgent.contains("AndroidApp")) {
                int start_index = userAgent.indexOf("(");
                int end_index = userAgent.indexOf(")");

                if (start != -1 && end != -1 && end > start) {
                    String deviceInfo = userAgent.substring(start_index + 1, end_index); // "Android 16; sdk_gphone64_arm64"
                    String[] parts = deviceInfo.split(";");

                    String osVersion = "Unknown Android Version";
                    String deviceModel = "Unknown Device";

                    if (parts.length >= 1) {
                        osVersion = parts[0].trim(); // "Android 16"
                    }

                    if (parts.length >= 2) {
                        deviceModel = parts[1].trim(); // "sdk_gphone64_arm64"
                    }

                    System.out.println("OS Version: " + osVersion);
                    System.out.println("Device Model: " + deviceModel);
                    LocalTime currentTime = LocalTime.now();
                    String timeOfDay = currentTime.toString();  // ISO-8601 format: HH:mm:ss.SSS
                    //MongoDB Logging
                    Document logDoc = new Document("device", deviceModel)
                            .append("osVersion", osVersion)
                            .append("time_of_day", timeOfDay)
                            .append("meal_type", meal_type)
                            .append("number_of_recipes_returned", filteredRecipes.size())
                            .append("response_time_ms", responseTime);

                    collection.insertOne(logDoc);

                }

                response.setContentType("application/json");
                response.setCharacterEncoding("UTF-8");
                PrintWriter out = response.getWriter();
                out.print(json_response);
                out.flush();


            } else {
                // Forward to output.jsp for browser view
                request.setAttribute("recipesJson", json_response);
                request.getRequestDispatcher("/output.jsp").forward(request, response);
            }

        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().print("{\"error\": \"Failed to fetch recipes. Data unavailable.\"}");
        }
    }
}
